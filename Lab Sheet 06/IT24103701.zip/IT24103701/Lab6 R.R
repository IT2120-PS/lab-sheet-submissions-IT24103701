getwd()
setwd("C:\\Users\\ASUS\\Desktop\\IT24103701")
#Q1
#Binomal distribution
pbinom(46, 50, 0.85,lower.tail = FALSE)

#Q2
#Number of calls received in given day
#poisson distribution
dpois(15, 12)
